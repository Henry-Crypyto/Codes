1. In Python_latest/Project_2_final.ipynb is the assignment file
2. There are 4 blocks of the code, execute first two block will generate the first iteration, the next two block will be the second iteration.
3. first_iteration.obj, second_iteration.obj are the results
4. There are already 4 completed obj in folder 'results'