#TODO
    * add support for obj, ply filetypes
    * move alclose, cross_product, etc. all helper functions to another file
